package com.blomni.o2o.order.util;




public class DefaultRestApiResponse<T> extends AbstractRestResponse<T>{
	
	
}
