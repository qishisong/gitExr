package com.blomni.o2o.order.exception;

public class NotDataException extends RuntimeException {

}
