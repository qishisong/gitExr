package com.blomni.o2o.order.vo;

public class SingleMemberVo {

	private String memberId;
	

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	
}

