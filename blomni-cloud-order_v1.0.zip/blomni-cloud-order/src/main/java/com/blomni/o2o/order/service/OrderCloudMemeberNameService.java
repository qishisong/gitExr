package com.blomni.o2o.order.service;

/**
 * 
* @ClassName: OrderCloudMemeberNameService 
* @Description: TODO(查询会员昵称) 
* @author zy 
* @date 2017年5月9日 下午9:23:58 
*
 */
public interface OrderCloudMemeberNameService {
	public String  getmemberNickById(String memberId);
}
