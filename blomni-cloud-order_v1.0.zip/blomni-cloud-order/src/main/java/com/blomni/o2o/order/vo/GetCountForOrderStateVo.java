package com.blomni.o2o.order.vo;

public class GetCountForOrderStateVo {

	private Integer orderCount;

	private String orderType;

	public Integer getOrderCount() {
		return orderCount;
	}

	public void setOrderCount(Integer orderCount) {
		this.orderCount = orderCount;
	}

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

}
