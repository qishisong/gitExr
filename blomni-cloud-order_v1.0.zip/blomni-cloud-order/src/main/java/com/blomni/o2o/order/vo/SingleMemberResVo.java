package com.blomni.o2o.order.vo;

import com.blomni.o2o.order.util.BaseResponse;

public class SingleMemberResVo extends  BaseResponse{
	private SingleMemberVo obj;

	public SingleMemberVo getObj() {
		return obj;
	}

	public void setObj(SingleMemberVo obj) {
		this.obj = obj;
	}
	
}

