package com.blomni.o2o.order.vo;

public class GoodVo {

	private String skuId;

	private String skuName;

	private Double goodsAmt;

	private String goodsImg;

	private String goodsName;

	private Integer goodsNum;

	public String getSkuId() {
		return skuId;
	}

	public void setSkuId(String skuId) {
		this.skuId = skuId;
	}

	public String getSkuName() {
		return skuName;
	}

	public void setSkuName(String skuName) {
		this.skuName = skuName;
	}

	public Double getGoodsAmt() {
		return goodsAmt;
	}

	public void setGoodsAmt(Double goodsAmt) {
		this.goodsAmt = goodsAmt;
	}

	public String getGoodsImg() {
		return goodsImg;
	}

	public void setGoodsImg(String goodsImg) {
		this.goodsImg = goodsImg;
	}

	public String getGoodsName() {
		return goodsName;
	}

	public void setGoodsName(String goodsName) {
		this.goodsName = goodsName;
	}

	public Integer getGoodsNum() {
		return goodsNum;
	}

	public void setGoodsNum(Integer goodsNum) {
		this.goodsNum = goodsNum;
	}

}
