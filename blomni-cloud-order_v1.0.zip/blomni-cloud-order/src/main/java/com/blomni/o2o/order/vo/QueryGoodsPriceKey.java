package com.blomni.o2o.order.vo;
/**
 * 
* @ClassName: QueryGoodsPriceKey 
* @Description: TODO(这里用一句话描述这个类的作用) 
* @author zy 
* @date 2017年5月11日 上午11:51:01 
*
 */
public class QueryGoodsPriceKey {
	private String resCode;
	private String msg;
	private QueryGoodsPrice obj;
	public String getResCode() {
		return resCode;
	}
	public void setResCode(String resCode) {
		this.resCode = resCode;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public QueryGoodsPrice getObj() {
		return obj;
	}
	public void setObj(QueryGoodsPrice obj) {
		this.obj = obj;
	}
	
	
}
