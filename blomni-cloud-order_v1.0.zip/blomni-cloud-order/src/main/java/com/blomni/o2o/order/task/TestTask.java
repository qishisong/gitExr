package com.blomni.o2o.order.task;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class TestTask {

	/*@Scheduled(cron = "0 0/1 * * * ?")
	public void executeFileDownLoadTask() {

		System.out.println("第一个方法"+Thread.currentThread().getName());  
		
	}
	
	@Scheduled(cron = "0 0/1 * * * ?")
	public void executeFileDownLoadTask2() {

		System.out.println("第二个方法"+Thread.currentThread().getName());  
		
	}*/

}
