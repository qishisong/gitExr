package com.blomni.o2o.order.exception;

public class ParamRuntimeException extends RuntimeException {

}
