package com.blomni.o2o.order.service;

import com.blomni.o2o.order.vo.QueryGoodsPriceKeyVo;

public interface QueryGoodsPriceKeyService {
	QueryGoodsPriceKeyVo queryGoodsPriceKey (String goodsCommId );
}
