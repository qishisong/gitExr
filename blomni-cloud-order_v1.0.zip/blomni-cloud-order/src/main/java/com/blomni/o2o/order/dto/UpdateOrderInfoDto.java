package com.blomni.o2o.order.dto;

public class UpdateOrderInfoDto {
	private String memberId;//会员id
	private String orderNo;//订单号
	private String remark;//卖家备注
	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	public String getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	
}
