package com.blomni.o2o.order.vo;
/**
 * 
* @ClassName: QueryGoodsPrice 
* @Description: TODO(这里用一句话描述这个类的作用) 
* @author zy 
* @date 2017年5月11日 下午2:30:24 
*
 */
public class QueryGoodsPrice {
	private QueryGoodsPriceKeyVo queryGoods;

	public QueryGoodsPriceKeyVo getQueryGoods() {
		return queryGoods;
	}

	public void setQueryGoods(QueryGoodsPriceKeyVo queryGoods) {
		this.queryGoods = queryGoods;
	}
	
	
}
