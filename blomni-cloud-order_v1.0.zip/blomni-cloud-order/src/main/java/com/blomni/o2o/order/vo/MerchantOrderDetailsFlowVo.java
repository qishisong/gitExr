package com.blomni.o2o.order.vo;

public class MerchantOrderDetailsFlowVo {
	private String buyerRemark;

	private String niceName;

	private String operatingTime;

	private String orderFlowState;
	private String sellerRemark;
	public String getBuyerRemark() {
		return buyerRemark;
	}
	public void setBuyerRemark(String buyerRemark) {
		this.buyerRemark = buyerRemark;
	}
	public String getNiceName() {
		return niceName;
	}
	public void setNiceName(String niceName) {
		this.niceName = niceName;
	}
	public String getOperatingTime() {
		return operatingTime;
	}
	public void setOperatingTime(String operatingTime) {
		this.operatingTime = operatingTime;
	}
	public String getOrderFlowState() {
		return orderFlowState;
	}
	public void setOrderFlowState(String orderFlowState) {
		this.orderFlowState = orderFlowState;
	}
	public String getSellerRemark() {
		return sellerRemark;
	}
	public void setSellerRemark(String sellerRemark) {
		this.sellerRemark = sellerRemark;
	}
	
	

}
